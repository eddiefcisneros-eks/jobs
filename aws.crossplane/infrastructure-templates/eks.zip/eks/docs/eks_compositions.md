<!---
#################################################################################################################
# The overall classification of this file is UNCLASSIFIED.
#
# NOTICE: This software was produced for the U. S. Government under Contract
# No. FA8702-19-C-0001, and is subject to the Rights in Noncommercial Computer
# Software and Noncommercial Computer Software Documentation Clause DFARS
# 252.227-7014 (FEB 2014)
#
# (c) 2023 The MITRE Corporation
#
# PROJECT: MVP - EKS Platform Deployment Prototype - Used to automate the deployment of EKS platform on AWS.
#
# FILE: MVP EKS Crossplane Composition
# CLASSIFICATION: Unclassified
# AUTHORS:  Thomas Yang (tzyang@mitre.org), Karpagam Balan (kbalan@mitre.org)
# CREATED: January, 2023
# DESCRIPTION: Documentation
###################################################################################################################
-->

# MVP EKS Crossplane Composition

# Crossplane Composite Resource reference

## This repository contains Prototype Crossplane Composite Resource Templates to deploy AWS Elastic Kubernetes Service and associated infrastructure over an existing AWS GovCloud Account 

### The following composite resources are defined in the template
- eksclusters.eks.platformone.io
- eksnetworks.eks.platformone.io
- eksstacks.eks.platformone.io

### The following claims are defined in the template
- ciclusters.eks.platform.io
- cistacks.eks.platformone

# Composite Resources

## 1. EKSCluster Composite Resource 

### The following are the input parameters for this composite resource


| Field           | Description |
| -----------------  | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| parameters.nodes.imageId   | Required. Type: string. AMI id of the image to be used on worker nodes. This can be the AMI id of a custom image or the Amazon Linux AMI that can be obtained with the command "aws ssm get-parameter --name /aws/service/eks/optimized-ami/1.27/amazon-linux-2/recommended/image_id --region "replace-with-your-region" --query "Parameter.Value" --output text"               |
| parameters.nodes.subnets   | Required. Type: array of strings. Array of subnet Ids into which the EKS worker nodes are provisioned|
| parameters.nodes.count | Required. Type: integer. Desireds number of worker nodes to deploy (Note: maximum nuber of nodes for small deployment is 25, medium size deployment is 50, and a large deployment is 100) |
| parameters.nodes.securityGroupIds | Required. Type: array of strings. Array of Security Group Ids to associate with the EKS worker nodes |
| parameters.nodes.size | Required. Type: string. Allowed values are small, medium and large. Small will deploy m5.large instances, medium will deploy m5.2xlarge instances and large will deploy m5.8xlarge instances |
| parameters.kmsKeyId | Optional. Type: string. Customer managed KMS key to be used for EBS volume encryption on the worker nodes. Defaults to "". If specified, "encrypted" flag must be set |
| parameters.encrypted | Optional. Type: string. Flag to indicate whether EBS volume is to be encrypted. Defaults to "false". If set kmsKeyId should be set to the arn of the key that should be used to encrypt the EBS volumes. |
| parameters.thumbprintList | Optional. Type: Array of strings. Defaults to thumbprint for us-gov-east-1. |
| parameters.csiAddonVersion | Optional. Type: string. Version of the AWS EBS CSI addon, Defaults to v1.19.0-eksbuild.2 |
| parameters.serviceIpv4Cidr | Optional. Type: string. Kubernetes Service IP CIDR. Defaults to 172.20.0.0/16 |
| parameters.volumeSize | Optional. Type: integer. Size of the second volume that is to be attached to the worker node instances. Defaults to 60G |
| parameters.keyName | Required. Type: string. Key pair name to be used at launch time for worker node instances. |
| parameters.subnetIds | Required. Type: Array of strings. Array of subnet Ids into which the controlplane interfaces are provisioned |
| parameters.securityGroupIds | Required. Type: array of strings. Array of Security Group Ids to associate with the EKS controlplan interfaces |
| parameters.region | Required. Type: string. The region us-gov-east-1 or us-gov-west-1 into where the cluster is being deployed |
| parameters.mapUsers | Optional. Type: string. User permissions that need to be added to the aws-auth configmap |
| parameters.bastionRoleArn | Optional. Type: string. The Role of the instance that requires access to the cluster |
| parameters.bastionInstanceId | Optional.Type: string. The instance ID of the instance that requires access to the cluster |
| parameters.version | Optional. Type: string. The version of the Kubernetes distro that is to be deployed. Defaults to 1.27 |
| parameters.endpointPublicAccess | Optional. Type: boolean. Enables or disables pulic endpoint of the provisioned EKS cluster. Defaults to false |



### The following managed resources are provisioned by this composition


| Resource           | Description |
| -----------------  | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Controlplane Role | Role assumed by the EKS control plane nodes |
| Controlplane Role Policy Attachment | This attaches the arn:aws-us-gov:iam::aws:policy/AmazonEKSClusterPolicy policy to the Controlplane Role |
| Nodegroup Role | This is the role assumed by the EKS worker node instances |
| Nodegroup Role Policy Attachments | These attach the arn:aws-us-gov:iam::aws:policy/AmazonEKSWorkerNodePolicy, arn:aws-us-gov:iam::aws:policy/service-role/AmazonEBSCSIDriverPolicy, arn:aws-us-gov:iam::aws:policy/AmazonEKS_CNI_Policy and arn:aws-us-gov:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly to the Nodegroup Role |
| EKS Cluster | The EKS cluster  |
| EKS ClusterAuth | This provisions the EKS cluster authorization secrets into a kubernetes secret |
| Launch Template | The Launch Template with details on worker node configurations |
| Node Group | EKS node group based on the launch template |
| OpenIDConnectProvider | IAM OpenId Connect provider for use with IRSA |
| AWS AUTH | Configmap that authorizes access to the cluster |
| Addon | AWS EBS CSI Addon |
| Storage Class | AWS EBS storage class managed by the csi addon|
| ProviderConfig | Kubernetes ProviderConfig for Crossplane to deploy Kubernetes Objects into the newly provisioned cluster |


## 2. EKSNetwork Composite Resource

### The following are the input parameters for this composite resource
    

| Field           | Description |
| -----------------  | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| parameters.bastion.imageId   | Required. Type: string. AMI id of the image to be used for the bastion instance.              |
| parameters.bastion.instanceType   | Required. Type: string. Type of instance for the bastion node |
| parameters.keyName | Required. Type: string. Key pair name to be used at launch time for worker node instances. |
| parameters.publicSubnetTag | Required. Type: string. Tag for the public subnets. |
| parameters.volumeSize | Optional. Type: integer. Size of the second volume attached to the worker node instances. Defaults to 60G |
| parameters.vpcCidr | Required. The CIDR block to be associated with the new VPC. |
| parameters.publicsubnet01 | Required. Type: string. CIDR range of the public subnet |
| parameters.publicsubnet02 | Required. Type: string. CIDR range of the public subnet |
| parameters.publicsubnet03 | Required. Type: string. CIDR range of the public subnet |
| parameters.privatesubnet01 | Required. Type: string. CIDR range of the private subnet |
| parameters.privatesubnet02 | Required. Type: string. CIDR range of the private subnet |
| parameters.privatesubnet03 | Required. Type: string. CIDR range of the private subnet |
| parameters.region | Required. Type: string. The region us-gov-east-1 or us-gov-west-1 into where the cluster is being deployed |


### The following managed resources are provisioned by this composition


| Resource           | Description |
| -----------------  | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| VPC | The VPC inside which all resources are to be deployed |
| Elastic IP | The public IP to be associated with NAT Gateway |
| Internet Gateway  | The Internet Gateway to be associated with the VPC |
| NAT Gateway | The NAT Gateway to be associated with the private subnets |
| Private subnets | Three private subnets where the EKS worker nodes are to be deployed  |
| Public subnets | The public subnets providing access to the internet |
| Private Route Table | Route Table for the private subnets |
| Public Route Table | Route Table for the public subnets |
| Private Routes | Routes to be associated with the private route table |
| Public Routes | Routes to be associated with the public route table |
| Private Route Table Associations | Association of private route table to the private subnets |
| Public Route Table Associations | Associants of public route table to the public subnets | 
| Security Group | Security Group to be associated with the bastion and all worker nodes |
| Security Group Rules | Security Group rules for the provisioned security group. Currenly allows all traffic |
| Public Subnet Tags | Tags to be associated with the public subnet |
| KMS Key | KMS key to be used with EBS encryption |
| Bastion Role | Role to be associated with the bastion instance |
| Bastion Role Policy Attachment | Policy to be associated with the Bation Role. Currentlythe AWS Admin policy is attached here |
| Bastion Instance Profile | The Instance Profile to be associated with the Batsion Instance |
| Bastion Instance | The Bation instance |

## 2. EKSStack  Composite Resource

### The following are the input parameters for this composite resource


| Field           | Description |
| -----------------  | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| parameters.bastion.imageId   | Required. Type: string. AMI id of the image to be used for the bastion instance.              |
| parameters.bastion.instanceType   | Required. Type: string. Type of instance for the bastion node |
| parameters.nodes.imageId   | Required. Type: string. AMI id of the image to be used on worker nodes. This can be the AMI id of a custom generated image or the Amazon Linux AMI that can be obtained with the command "aws ssm get-parameter --name /aws/service/eks/optimized-ami/1.27/amazon-linux-2/recommended/image_id --region <name-of-region> --query "Parameter.Value" --output text"               |
| parameters.nodes.count | Required. Type: integer. Desireds number of worker nodes to deploy (Note: maximum nuber of nodes for small deployment is 25, medium size deployment is 50, and a large deployment is 100) |
| parameters.nodes.size | Required. Type: string. Allowed values are small, medium and large. Small will deploy m5.large instances, medium will deploy m5.2xlarge instances and large will deploy m5.8xlarge instances |
| parameters.keyName | Required. Type: string. Key pair name to be used at launch time for worker node instances. |
| parameters.volumeSize | Optional. Type: integer. Size of the second volume attached to the worker node instances. Defaults to 60G |
| parameters.thumbprintList | Optional. Type: Array of strings. Defaults to thumbprint for us-gov-east-1. |
| parameters.csiAddonVersion | Optional. Type: string. Version of the AWS EBS CSI addon, Defaults to v1.19.0-eksbuild.2 |
| parameters.serviceIpv4Cidr | Optional. Type: string. Kubernetes Service IP CIDR. Defaults to 172.20.0.0/16 |
| parameters.vpcCidr | Required. Type: string. The CIDR block to be associated with the new VPC. |
| parameters.publicsubnet01 | Required. Type: string. CIDR range of the public subnet |
| parameters.publicsubnet02 | Required. Type: string. CIDR range of the public subnet |
| parameters.publicsubnet03 | Required. Type: string. CIDR range of the public subnet |
| parameters.privatesubnet01 | Required. Type: string. CIDR range of the private subnet |
| parameters.privatesubnet02 | Required. Type: string. CIDR range of the private subnet |
| parameters.privatesubnet03 | Required. Type: string. CIDR range of the private subnet |
| parameters.region | Required. Type: string. The region us-gov-east-1 or us-gov-west-1 into where the cluster is being deployed |
| parameters.mapUsers | Optional. Type: string. User permissions that need to be added to the aws-auth configmap |
| parameters.version | Optional. Type: string. The version of the Kubernetes distro that is to be deployed. Defaults to 1.27 |


### The following resources are provisioned by this composition

Deploys EKSCluster and EKSNetwork Composites which in turn deploy above listed managed resources.

# Composite Resource Claims

## 1. CiCluster Composite Resource Claim

The CiCluster Claim provisions a claim of the EKSCluster Composite Resource. The Connection details (and the kubeconfig) are written back as a Kubernetes secret into the namespace where the claim was provisioned. 

## 2. CiStack Composite Resource Claim

The CiStack Claim provisions a claim of the EKSStack Composite Resource. The Connection details (and the kubeconfig) are written back as a Kubernetes secret into the namespace where the claim was provisioned. 

# Notes

## Crossplane deployment

The helm chart that installs crossplane can be found here https://repo1.dso.mil/big-bang/product/community/crossplane. Valid repo1 and IB credentials are required inorder to dpeloy the chart. Crossplane can be deployed as a package wrapper around Big Bang. An example addition to the BigBang deployment configuration values could be.
```
packages:
  crossplane:
    enabled: true
    namespace:
      name: crossplane-system
    git:
      repo: "https://repo1.dso.mil/big-bang/product/community/crossplane.git"
      tag: "1.12.2-bb.0"
      path: "chart"
    values:
      resourcesCrossplane:
        limits:
          # -- CPU resource limits for Crossplane.
          cpu: 1
          # -- Memory resource limits for Crossplane.
          memory: 1Gi
        requests:
          # -- CPU resource requests for Crossplane.
          cpu: 100m
          # -- Memory resource requests for Crossplane.
          memory: 256Mi
      provider:
        packages:
        - xpkg.upbound.io/upbound/provider-aws-iam:v0.37.0
        - xpkg.upbound.io/upbound/provider-aws-ec2:v0.37.0
        - xpkg.upbound.io/upbound/provider-aws-eks:v0.37.0
        - xpkg.upbound.io/upbound/provider-aws-kms:v0.37.0
        - xpkg.upbound.io/upbound/provider-aws-cloudwatchlogs:v0.37.0
        - xpkg.upbound.io/upbound/provider-aws-iam:v0.37.0
        - xpkg.upbound.io/upbound/provider-family-aws:v0.37.0
        - xpkg.upbound.io/crossplane-contrib/provider-kubernetes:v0.9.0
       
 ```
The above installs Crossplane 1.12.2-bb.0 into an existing cluster. Additionly a list of providers are installed which allow for resource creation on the AWS cloud and on the target EKS kubernetes cluster. Distroctl automates deployment of Crossplane onto a KinD cluster on the bootstrap EC2 instance and leverages the manifests from the bootstrap-manifests folder of this repository. 

## Infrastructure deployment

The Crossplane configuration can be manually installed using the Crossplane Kubectl extension https://releases.crossplane.io/stable/<version>/bin/linux_amd64/crank. Successful installation will result in provisioning the CRDs for the Compositions and Claims that can be subsequently leveraged to deploy the platform.

To deploy an EKS cluster into an existing network, the EKSCluster composite or the CiCluster claim should be used. Pelase see a reference example in the examples folder. If no KMS key is provided, the worker node EBS volumes are by default not encrypted. If a KMS key is provided in the manifest, the encryption field should also be set to true. 

When the entire stack (network + cluster) needs to be deployed, EKSStack composite or CiStack claim can be used. This creates a KMS key and encrypts the deployed volumes both for the bastion and the worker nodes. An open security group is created and attached both to the bastion, and the EKS controlplane and worker nodes. The template can be modified to incorporate custom security groups that allow for specific ports and IPs to be whitelisted. Refer to https://marketplace.upbound.io/providers/upbound/provider-aws-ec2/v0.40.0/resources/ec2.aws.upbound.io/SecurityGroupRule/v1beta1 for details on the specifics. After the cluster is deployed in response to a claim, the connection secret is written in the values field of the secret deployed back into the claim namespace. The prototype deploys EKS version 1.27 by default and the custom AMI code is built by default for Kubernetes version v1.27.3. The prototype has been tested for EKS version 1.27 (the latest release at the time of writing). The template could be tested for later versions (when released) by appropriately providing an AMAZON EKS Optimized AMi version and the appropriate EKS version value in the EKS deployment manifest. The prototype is templated to deploy over AWS gov cloud partition and supports two regions us-gov-east-1 and us-gov-west-1 and can be modified to deploy to other environments.

## Crossplane RBAC with Claims

Crossplane Claims are namespaced. To restrict access to the cluster resources and the managed resources provisioned by Crossplane in response to the Claim deployment, annotations in the namespace manifest and Kubernetes native RBAC resources may be leveraged. For example:
```
---
apiVersion: v1
kind: Namespace
metadata:
  name: example
  labels:
    app.kubernetes.io/name: example
  annotations:
    rbac.crossplane.io/ciclusters.eks.platformone.io: xrd-claim-accepted
---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: example-sa
  namespace: example-namespace
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: example-role
  namespace: example-namespace
rules:
- apiGroups: [""]
  resources: ["secrets"]
  verbs: ["get", "watch", "list", "create", "update"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: example-rolebinding
  namespace: example-namespace
roleRef:
  apiGroup: ""
  kind: Role
  name: example-role
subjects:
- kind: ServiceAccount
  name: example-sa
  namespace: example-namespace
---
apiVersion: rbac.authorization.k8s.io/v1

kind: RoleBinding
metadata:
  name: example-rolebinding-crossplane-edit
  namespace: example-namespace
roleRef:
  apiGroup: ""
  kind: Role
  name: "crossplane-edit"
subjects:
- kind: ServiceAccount
  name: example-sa
  namespace: example-namespace
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: example-cluster-rolebinding
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: "crossplane-view"
subjects:
- kind: ServiceAccount
  name: example-sa
  namespace: example-namespace
```

## GitOps with Crossplane

An example of EKS cluster provisioning with helm charts can be found in the examples directory. Flux or ArgoCD can further be used to automate deployment with GitOps processes. When using Argocd, the Argocd configmap needs to have the following resource trackingmethod enabled.
```
  application.resourceTrackingMethod: annotation
```

## Integration with Kyverno

Since infrastructure resources are Kubernetes API objects, Kyverno can be leveraged to validate or mutate resource configurations and enforce policies.

## IRSA integration

The prototype provisions an IAM OIDC identity provider with the EKS cluster issuer. This can be used for further integrating application deployments with IAM Roles based on Service Accounts (IRSA). Please refer to https://docs.aws.amazon.com/eks/latest/userguide/associate-service-account-role.html and https://docs.aws.amazon.com/eks/latest/userguide/pod-configuration.html for furtehr details.

 
## Status of deployment

To view the status of all the composite resources deployed in the cluster
```
kubectl get composite
```

To view the status of all the managed resources deployed in the cluster
```
kubectl get managed
```

To view the status of all the claims deployed in the cluster
```
kubectl get claim -A
```
When the EKS cluster is deployed successfully and all resources are in teh "READY" state, the kubeconfig for the deployed EKS cluster is written in the "value" key of the kubernetes secret (the name of the secret is provided by the user in the writeConnectionSecretToRef.name field when deploying the claim) in the claim's namespace.








