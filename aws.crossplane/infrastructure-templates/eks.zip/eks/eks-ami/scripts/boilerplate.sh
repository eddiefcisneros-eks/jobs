#!/usr/bin/env bash

set -ex
set -o pipefail
set -o nounset
set -o errexit
IFS=$'\n\t'
export AWS_DEFAULT_OUTPUT="json"

################################################################
# Migrate existing folder to a new partition
#
# Globals:
#   None
# Arguments:
#   1 - the path of the disk or partition
#   2 - the folder path to migration
#   3 - the mount options to use.
# Outputs:
#   None
################################################################
migrate_and_mount_disk() {
    local disk_name=$1
    local folder_path=$2
    local mount_options=$3
    local temp_path="/mnt${folder_path}"
    local old_path="${folder_path}-old"

    # install an ext4 filesystem to the disk
    mkfs -t ext4 ${disk_name}

    # check if the folder already exists
    if [ -d "${folder_path}" ]; then
        mkdir -p ${temp_path}
        mount ${disk_name} ${temp_path}
        cp -Rax ${folder_path}/* ${temp_path}
        mv ${folder_path} ${old_path}
        umount ${disk_name}
    fi

    # create the folder
    mkdir -p ${folder_path}

    # add the mount point to fstab and mount the disk
    echo "UUID=$(blkid -s UUID -o value ${disk_name}) ${folder_path} ext4 ${mount_options} 0 1" >> /etc/fstab
    mount -a

    # if selinux is enabled restore the objects on it
    if selinuxenabled; then
        restorecon -R ${folder_path}
    fi
}

################################################################
# Partition the disks based on the standard layout for common
# hardening frameworks
#
# Globals:
#   None
# Arguments:
#   1 - the name of the disk
# Outputs:
#   None
################################################################
partition_disks() {
    local disk_name=$1

    # partition the disk
    parted -a optimal -s $disk_name \
        mklabel gpt \
        mkpart var ext4 0% 20% \
        mkpart varlog ext4 20% 40% \
        mkpart varlogaudit ext4 40% 60% \
        mkpart home ext4 60% 70% \
        mkpart varlibcontainerd ext4 70% 90%

    # wait for the disks to settle
    sleep 5

    # migrate and mount the existing
    migrate_and_mount_disk "${disk_name}p1" /var            defaults,nofail,nodev
    migrate_and_mount_disk "${disk_name}p2" /var/log        defaults,nofail,nodev,nosuid
    migrate_and_mount_disk "${disk_name}p3" /var/log/audit  defaults,nofail,nodev,nosuid
    migrate_and_mount_disk "${disk_name}p4" /home           defaults,nofail,nodev,nosuid
    migrate_and_mount_disk "${disk_name}p5" /var/lib/containerd defaults,nofail
}

################################################################################
### Machine Architecture #######################################################
################################################################################

MACHINE=$(uname -m)
ARCH="amd64"
if [ "$MACHINE" != "x86_64" ]; then
    echo "Unknown machine architecture '$MACHINE'" >&2
    exit 1
fi

################################################################################
### Validate Required Arguments ################################################
################################################################################
validate_env_set() {
    (
        set +o nounset

        if [ -z "${!1}" ]; then
            echo "Packer variable '$1' was not set. Aborting"
            exit 1
        fi
    )
}

validate_env_set CNI_PLUGIN_VERSION
validate_env_set KUBERNETES_VERSION
validate_env_set ARCH
validate_env_set AWS_KUBELET_VER
validate_env_set BUILD_VERSION
validate_env_set CNI_PLUGIN_VERSION
validate_env_set ECR_CREDENTIAL_PROVIDER_VERSION
validate_env_set FLUX_VER
validate_env_set HELM_VER
validate_env_set IAM_AUTH_VER
validate_env_set KUBECTL_VER
validate_env_set KUBERNETES_AWS_BIN_VERSION
validate_env_set KUBERNETES_VERSION
validate_env_set KUSTOMIZE_VERSION
validate_env_set SHA_CNI_PLUGINS
validate_env_set SHA_ECR_CREDENTIAL_PROVIDER
validate_env_set SHA_FLUX
validate_env_set SHA_IAM_AUTH
validate_env_set SHA_HELM
validate_env_set SHA_KUBECTL
validate_env_set SHA_KUBELET
validate_env_set SHA_KUSTOMIZE

################################################################
# Wait for the cloud-init process to finish before moving
# to the next step.
#
# Globals:
#   None
# Arguments:
#   None
# Outputs:
#   0 finishes when the cloud-init process is complete
################################################################
wait_for_cloudinit() {
    cloud-init status --wait
}

# wait for cloud-init to finish
wait_for_cloudinit

sudo setenforce 0
sudo sed -i 's/^SELINUX=enforcing$/SELINUX=permissive/' /etc/selinux/config
sudo swapoff -a

################################################################################
### Packages ###################################################################
################################################################################

sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
dnf install -y https://dl.fedoraproject.org/pub/archive/fedora/linux/releases/28/Everything/x86_64/os/Packages/i/iptables-libs-1.6.2-2.fc28.x86_64.rpm
dnf install -y https://dl.fedoraproject.org/pub/archive/fedora/linux/releases/28/Everything/x86_64/os/Packages/i/iptables-1.6.2-2.fc28.x86_64.rpm
yum install -y ca-certificates openssl chrony conntrack-tools curl yum-utils ipvsadm jq nfs-utils socat unzip wget yum-plugin-versionlock device-mapper-persistent-data lvm2 socat containerd.io runc audit audit-libs parted unzip redhat-lsb-core  openscap-scanner scap-security-guide


################################################################################
### Disable Firewalld  ###################################################################
################################################################################
systemctl disable firewalld && systemctl stop firewalld
sudo systemctl stop nm-cloud-setup.timer && sudo systemctl disable nm-cloud-setup.timer
sudo systemctl stop nm-cloud-setup && sudo systemctl disable nm-cloud-setup

################################################################################
### Enable Audit Log ###################################################################
################################################################################
systemctl enable auditd && systemctl start auditd

################################################################################
### Install AWS ClI ###################################################################
################################################################################
curl -sL -o aws.zip "https://awscli.amazonaws.com/awscli-exe-linux-$(uname -m).zip"
unzip aws.zip
./aws/install -i /usr/local/aws-cli -b /usr/bin
rm -f aws.zip

################################################################################
### Partition Disks ###################################################################
################################################################################
systemctl stop tuned rsyslog crond irqbalance polkit chronyd NetworkManager
partition_disks /dev/nvme1n1

################################################################################
### Install Binaries  ###################################################################
################################################################################

TEMPLATE_DIR=${TEMPLATE_DIR:-/etc/packer/files}
#kubelet
curl -LO https://distro.eks.amazonaws.com/$KUBERNETES_AWS_BIN_VERSION/releases/$BUILD_VERSION/artifacts/kubernetes/$AWS_KUBELET_VER/bin/linux/$ARCH/kubelet
if [[ ! $(sha256sum kubelet) =~ $SHA_KUBELET ]]
then
    echo Warning: Checksum mismatch for kubelet.
    echo Expected: $SHA_KUBELET
    echo Actual: $(sha256sum kubelet)
fi
chmod a+x kubelet
mv kubelet /usr/bin/.


#aws-iam-authenticator
wget https://distro.eks.amazonaws.com/$KUBERNETES_AWS_BIN_VERSION/releases/$BUILD_VERSION/artifacts/aws-iam-authenticator/$IAM_AUTH_VER/aws-iam-authenticator-linux-$ARCH-$IAM_AUTH_VER.tar.gz
tar xvf aws-iam-authenticator-linux-$ARCH-$IAM_AUTH_VER.tar.gz
if [[ ! $(sha256sum aws-iam-authenticator) =~ $SHA_IAM_AUTH ]]
then
    echo Warning: Checksum mismatch for iam auth.
    echo Expected: $SHA_IAM_AUTH
    echo Actual: $(sha256sum aws-iam-authenticator)
fi
chmod a+x aws-iam-authenticator
mv aws-iam-authenticator /usr/bin/.
rm aws-iam-authenticator-linux-$ARCH-$IAM_AUTH_VER.tar.gz


#cni-plugins.tgz
wget https://distro.eks.amazonaws.com/$KUBERNETES_AWS_BIN_VERSION/releases/$BUILD_VERSION/artifacts/plugins/$CNI_PLUGIN_VERSION/cni-plugins-linux-$ARCH-$CNI_PLUGIN_VERSION.tar.gz
if [[ ! $(sha256sum cni-plugins-linux-$ARCH-$CNI_PLUGIN_VERSION.tar.gz) =~ $SHA_CNI_PLUGINS ]]
then
    echo Warning: Checksum mismatch for cni plugins.
    echo Expected: $SHA_CNI_PLUGINS
    echo Actual: $(sha256sum cni-plugins-linux-$ARCH-$CNI_PLUGIN_VERSION.tar.gz)
fi
sudo mkdir -p /opt/cni/bin
sudo tar -xvf "cni-plugins-linux-$ARCH-$CNI_PLUGIN_VERSION.tar.gz" -C /opt/cni/bin
rm cni-plugins-linux-$ARCH-$CNI_PLUGIN_VERSION.tar.gz 

#ecr-credential-provider
sudo mkdir -p /etc/eks
wget https://github.com/rancher/wharfie/releases/download/$ECR_CREDENTIAL_PROVIDER_VERSION/ecr-credential-provider-$ARCH
if [[ ! $(sha256sum ecr-credential-provider-$ARCH) =~ $SHA_ECR_CREDENTIAL_PROVIDER ]]
then
    echo Warning: Checksum mismatch for ecr cred provider.
    echo Expected: $SHA_ECR_CREDENTIAL_PROVIDER
    echo Actual: $(sha256sum ecr-credential-provider-$ARCH)
fi
chmod a+x ecr-credential-provider-$ARCH
cp ecr-credential-provider-$ARCH /etc/eks/ecr-credential-provider
mv ecr-credential-provider-$ARCH /usr/bin/ecr-credential-provider

#flux
wget https://github.com/fluxcd/flux2/releases/download/v$FLUX_VER/flux_"$FLUX_VER"_linux_$ARCH.tar.gz
chmod 755 flux_"$FLUX_VER"_linux_$ARCH.tar.gz
tar -xzof flux_"$FLUX_VER"_linux_$ARCH.tar.gz
if [[ ! $(sha256sum flux) =~ $SHA_FLUX ]]
then
    echo Warning: Checksum mismatch for Flux.
    echo Expected: $SHA_FLUX
    echo Actual: $(sha256sum flux)
fi
mv flux /usr/bin/.
rm flux_"$FLUX_VER"_linux_$ARCH.tar.gz

#helm
wget https://get.helm.sh/helm-$HELM_VER-linux-$ARCH.tar.gz
tar -zxvf helm-$HELM_VER-linux-$ARCH.tar.gz
if [[ ! $(sha256sum linux-$ARCH/helm) =~ $SHA_HELM ]]
then
    echo Warning: Checksum mismatch for Helm.
    echo Expected: $SHA_HELM
    echo Actual: $(sha256sum linux-$ARCH/helm)
fi

chmod a+x linux-$ARCH/helm
mv linux-$ARCH/helm /usr/bin/.

rm -r linux-$ARCH/
rm helm-$HELM_VER-linux-$ARCH.tar.gz


#kubectl
curl -LO "https://dl.k8s.io/$KUBECTL_VER/bin/linux/$ARCH/kubectl"
if [[ ! $(sha256sum kubectl) =~ $SHA_KUBECTL ]]
then
    echo Warning: Checksum mismatch for kubectl.
    echo Expected: $SHA_KUBECTL
    echo Actual: $(sha256sum kubectl)
fi
chmod a+x kubectl
mv kubectl /usr/bin/.


#kustomize
curl -sLO https://github.com/kubernetes-sigs/kustomize/releases/download/kustomize/$KUSTOMIZE_VERSION/kustomize_${KUSTOMIZE_VERSION}_linux_$ARCH.tar.gz
tar xzf ./kustomize_v*_linux_$ARCH.tar.gz
if [[ ! $(sha256sum kustomize) =~ $SHA_KUSTOMIZE ]]
then
    echo Warning: Checksum mismatch for kustomize.
    echo Expected: $SHA_KUSTOMIZE
    echo Actual: $(sha256sum kustomize)
fi
sudo chmod -R a+x kustomize
mv kustomize /usr/bin/.
rm ./kustomize_v*_linux_$ARCH.tar.gz

sudo chmod -R a+x $TEMPLATE_DIR/bin/imds
cp $TEMPLATE_DIR/bin/imds /usr/bin/.



################################################################################
### Utilities ##################################################################
################################################################################


# Remove the ec2-net-utils package, if it's installed. This package interferes with the route setup on the instance.
if yum list installed | grep ec2-net-utils; then sudo yum remove ec2-net-utils -y -q; fi

################################################################################
### Time #######################################################################
################################################################################

# Make sure Amazon Time Sync Service starts on boot.
sudo chkconfig chronyd on

# Make sure that chronyd syncs RTC clock to the kernel.
cat <<EOF | sudo tee -a /etc/chrony.conf
# This directive enables kernel synchronisation (every 11 minutes) of the
# real-time clock. Note that it can’t be used along with the 'rtcfile' directive.
rtcsync
EOF

# If current clocksource is xen, switch to tsc
if grep --quiet xen /sys/devices/system/clocksource/clocksource0/current_clocksource &&
  grep --quiet tsc /sys/devices/system/clocksource/clocksource0/available_clocksource; then
    echo "tsc" | sudo tee /sys/devices/system/clocksource/clocksource0/current_clocksource
else
    echo "tsc as a clock source is not applicable, skipping."
fi

################################################################################
### SSH ########################################################################
################################################################################

# Disable weak ciphers
echo -e "\nCiphers aes128-ctr,aes256-ctr,aes128-gcm@openssh.com,aes256-gcm@openssh.com" | sudo tee -a /etc/ssh/sshd_config
sudo systemctl restart sshd.service

###############################################################################
### Containerd setup ##########################################################
###############################################################################

sudo mkdir -p /etc/eks/containerd
sudo cp $TEMPLATE_DIR/containerd-config.toml /etc/eks/containerd/containerd-config.toml
sudo cp $TEMPLATE_DIR/kubelet-containerd.service /etc/eks/containerd/kubelet-containerd.service
sudo cp $TEMPLATE_DIR/sandbox-image.service /etc/eks/containerd/sandbox-image.service
sudo cp $TEMPLATE_DIR/pull-sandbox-image.sh /etc/eks/containerd/pull-sandbox-image.sh 
sudo chmod a+x /etc/eks/containerd/pull-sandbox-image.sh
sudo cp $TEMPLATE_DIR/pull-image.sh /etc/eks/containerd/pull-image.sh 
sudo chmod a+x /etc/eks/containerd/pull-image.sh
cat <<EOF | sudo tee -a /etc/modules-load.d/containerd.conf
overlay
br_netfilter
EOF

cat <<EOF | sudo tee -a /etc/sysctl.d/99-kubernetes-cri.conf
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
net.ipv4.ip_forward = 1
EOF

sudo modprobe overlay
sudo modprobe br_netfilter



################################################################################
### Logrotate ##################################################################
################################################################################

# kubelet uses journald which has built-in rotation and capped size.
# See man 5 journald.conf
sudo cp $TEMPLATE_DIR/logrotate-kube-proxy /etc/logrotate.d/kube-proxy
sudo cp $TEMPLATE_DIR/logrotate.conf /etc/logrotate.conf
sudo chown root:root /etc/logrotate.d/kube-proxy
sudo chown root:root /etc/logrotate.conf
sudo mkdir -p /var/log/journal

################################################################################
### Kubernetes #################################################################
################################################################################

sudo mkdir -p /etc/kubernetes/manifests
sudo mkdir -p /var/lib/kubernetes
sudo mkdir -p /var/lib/kubelet

sudo mkdir -p /etc/kubernetes/kubelet
sudo mkdir -p /etc/systemd/system/kubelet.service.d

sudo cp $TEMPLATE_DIR/kubelet-kubeconfig /var/lib/kubelet/kubeconfig
sudo chown root:root /var/lib/kubelet/kubeconfig

sudo cp $TEMPLATE_DIR/kubelet-containerd.service /etc/systemd/system/kubelet.service
sudo chown root:root /etc/systemd/system/kubelet.service

sudo cp $TEMPLATE_DIR/kubelet-config.json /etc/kubernetes/kubelet/kubelet-config.json
sudo chown root:root /etc/kubernetes/kubelet/kubelet-config.json

sudo systemctl daemon-reload
sudo systemctl disable kubelet

################################################################################
### EKS ########################################################################
################################################################################

sudo mkdir -p /etc/eks
sudo cp $TEMPLATE_DIR/eni-max-pods.txt /etc/eks/eni-max-pods.txt
sudo cp $TEMPLATE_DIR/bootstrap.sh /etc/eks/bootstrap.sh
sudo chmod +x /etc/eks/bootstrap.sh
sudo cp $TEMPLATE_DIR/kubelet.yaml /etc/eks/.
sudo cp $TEMPLATE_DIR/max-pods-calculator.sh /etc/eks/max-pods-calculator.sh
sudo chmod +x /etc/eks/max-pods-calculator.sh
sudo cp $TEMPLATE_DIR/get-ecr-uri.sh /etc/eks/get-ecr-uri.sh
sudo chmod +x /etc/eks/get-ecr-uri.sh
sudo chown -R root:root /etc/eks

################################################################################
### Additional sysctl configurations    #############################
################################################################################

cat <<EOF | sudo tee -a /etc/sysctl.d/99-amazon.conf
vm.overcommit_memory=1
kernel.panic=10
kernel.panic_on_oops=1
fs.inotify.max_user_watches=524288
fs.inotify.max_user_instances=8192
net.ipv4.conf.all.accept_source_route=0  
net.ipv4.conf.default.accept_source_route=0 
vm.max_map_count=524288
net.ipv4.conf.all.promote_secondaries=1
net.ipv4.conf.default.promote_secondaries=1
net.ipv4.conf.all.rp_filter=1
net.ipv4.conf.default.rp_filter=1
EOF
sudo sysctl -p
sysctl --system

################################################################################
### Turn on Fips mode   ########################################################
################################################################################

fips-mode-setup --enable

reboot
